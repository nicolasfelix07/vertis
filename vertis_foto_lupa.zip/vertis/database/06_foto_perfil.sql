-- =====================================================================
-- VÉRTIS — 06: FOTO DE PERFIL
-- Rode DEPOIS do 05_loja_cupons.sql. Pode rodar mais de uma vez.
--
-- A foto NÃO cria tabela nova (o banco continua com 47 tabelas):
-- é uma coluna da própria tabela clientes (relação 1:1 natural).
-- O app recorta a foto em círculo, reduz para 256×256 e envia em PNG.
-- =====================================================================
SET NAMES utf8mb4;
USE vertis;

-- MySQL não tem "ADD COLUMN IF NOT EXISTS": conferimos no dicionário de dados antes.
SET @existe := (SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'clientes' AND COLUMN_NAME = 'foto_perfil');
SET @sql := IF(@existe = 0,
  'ALTER TABLE clientes
     ADD COLUMN foto_perfil MEDIUMBLOB NULL COMMENT ''PNG 256x256 recortado em círculo pelo app'',
     ADD COLUMN foto_atualizada_em DATETIME NULL',
  'SELECT ''coluna foto_perfil já existe'' AS aviso');
PREPARE comando FROM @sql;
EXECUTE comando;
DEALLOCATE PREPARE comando;
