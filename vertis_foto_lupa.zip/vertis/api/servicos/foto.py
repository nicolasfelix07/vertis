"""
FOTO DE PERFIL
==============
O APP faz a computação gráfica (recorte circular, zoom, reamostragem) e
envia só o resultado: um PNG 256×256 com fundo transparente fora do círculo.
A API apenas CONFERE se é mesmo um PNG pequeno e guarda em clientes.foto_perfil.
"""
import base64
import binascii
import struct

import relogio
from db import consultar_um, executar, auditar

ASSINATURA_PNG = b"\x89PNG\r\n\x1a\n"
TAMANHO_MAXIMO = 400 * 1024      # 400 KB
LADO_MAXIMO = 512


def _validar(png: bytes):
    if not png.startswith(ASSINATURA_PNG) or png[12:16] != b"IHDR":
        raise ValueError("A foto precisa ser uma imagem PNG")
    if len(png) > TAMANHO_MAXIMO:
        raise ValueError("Foto grande demais (máximo 400 KB)")
    largura, altura = struct.unpack(">II", png[16:24])     # o cabeçalho IHDR guarda largura e altura
    if not (16 <= largura <= LADO_MAXIMO and 16 <= altura <= LADO_MAXIMO):
        raise ValueError(f"A foto deve ter entre 16 e {LADO_MAXIMO} pixels de lado")
    return largura, altura


def salvar(con, cliente_id, imagem_base64: str) -> dict:
    try:
        png = base64.b64decode(imagem_base64, validate=True)
    except (binascii.Error, ValueError):
        raise ValueError("Imagem inválida")
    largura, altura = _validar(png)
    executar(con, "UPDATE clientes SET foto_perfil=%s, foto_atualizada_em=%s WHERE id=%s",
             (png, relogio.agora(), cliente_id))
    auditar(con, "alterou_foto_perfil", "clientes", cliente_id, None,
            {"largura": largura, "altura": altura, "bytes": len(png)}, ator_tipo="cliente", ator_id=cliente_id)
    return {"ok": True, "largura": largura, "altura": altura, "bytes": len(png)}


def obter(con, cliente_id) -> dict:
    r = consultar_um(con, "SELECT foto_perfil, foto_atualizada_em FROM clientes WHERE id=%s", (cliente_id,))
    if not r or not r["foto_perfil"]:
        return {"imagem_base64": None, "atualizada_em": None}
    return {"imagem_base64": base64.b64encode(r["foto_perfil"]).decode(),
            "atualizada_em": r["foto_atualizada_em"]}


def remover(con, cliente_id) -> dict:
    executar(con, "UPDATE clientes SET foto_perfil=NULL, foto_atualizada_em=NULL WHERE id=%s", (cliente_id,))
    auditar(con, "removeu_foto_perfil", "clientes", cliente_id, None, None, ator_tipo="cliente", ator_id=cliente_id)
    return {"ok": True}


def tem_foto(con, cliente_id):
    r = consultar_um(con, "SELECT foto_atualizada_em FROM clientes WHERE id=%s AND foto_perfil IS NOT NULL",
                     (cliente_id,))
    return r["foto_atualizada_em"] if r else None
