"""
FOTO DE PERFIL — RECORTE E AMPLIAÇÃO
===================================
Problema: a foto da galeria quase nunca está no formato certo (retangular,
pessoa fora do centro, muito longe). O cliente precisa escolher QUE PARTE
da foto vira o avatar redondo.

Computação gráfica usada (cg/janela.py):
  • JANELA → VIEWPORT: o quadrado da tela mostra uma "janela" da foto;
  • ZOOM em torno do ponto da pinça (a foto não "foge" dos dedos);
  • RECORTE: a janela nunca sai da foto (sem bordas vazias);
  • REAMOSTRAGEM BILINEAR + superamostragem → PNG 256×256;
  • MÁSCARA CIRCULAR com borda suave (antialiasing por cobertura).
O app envia só o resultado para a API (PUT /me/foto).
"""
import base64
import io
import os
import struct
import zlib

from kivy.core.image import Image as CoreImage
from kivy.factory import Factory
from kivy.graphics import Color, Ellipse
from kivy.metrics import dp, sp
from kivy.properties import ObjectProperty, StringProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView
from kivy.uix.slider import Slider
from kivy.uix.widget import Widget

import servidor
from cg import janela as jn
from tema import CORES, rgba
from telas.componentes import aviso
from telas.imagens import carregar_imagem, escolher_imagem

EXEMPLO = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "foto_exemplo.jpg")
LADO_FOTO = 256


# ---------------------------------------------------------------- PNG (sem bibliotecas externas)
def codificar_png(rgba_baixo_para_cima) -> bytes:
    """Matriz RGBA (linha 0 embaixo, padrão do Kivy) → bytes de um arquivo PNG."""
    img = rgba_baixo_para_cima[::-1]                     # PNG guarda de CIMA para baixo
    h, w = img.shape[:2]
    linhas = b"".join(b"\x00" + img[i].tobytes() for i in range(h))   # filtro 0 em cada linha

    def bloco(tipo, dados):
        return struct.pack(">I", len(dados)) + tipo + dados + struct.pack(">I", zlib.crc32(tipo + dados))
    return (b"\x89PNG\r\n\x1a\n" + bloco(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + bloco(b"IDAT", zlib.compress(linhas, 9)) + bloco(b"IEND", b""))


def textura_de_png(png: bytes):
    return CoreImage(io.BytesIO(png), ext="png").texture


# ---------------------------------------------------------------- avatar (tela Início)
class AvatarFoto(ButtonBehavior, Widget):
    """Círculo com a FOTO (se houver) ou as INICIAIS. Tocar abre o menu da foto."""
    iniciais = StringProperty("")
    textura = ObjectProperty(None, allownone=True)

    def __init__(self, **kw):
        super().__init__(**kw)
        self._rotulo = Label(bold=True, font_size=sp(15), color=rgba(CORES["amarelo"]))
        self.add_widget(self._rotulo)
        self.bind(pos=self._desenhar, size=self._desenhar, textura=self._desenhar, iniciais=self._desenhar)

    def _desenhar(self, *_):
        lado = min(self.width, self.height)
        x, y = self.x + (self.width - lado) / 2, self.y + (self.height - lado) / 2
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*rgba(CORES["grafite"]))
            Ellipse(pos=(x, y), size=(lado, lado))
            if self.textura is not None:
                Color(1, 1, 1, 1)
                Ellipse(pos=(x, y), size=(lado, lado), texture=self.textura)
        self._rotulo.text = "" if self.textura is not None else self.iniciais
        self._rotulo.pos, self._rotulo.size = (x, y), (lado, lado)


class CacheFoto:
    """Guarda a foto já baixada (a API só é chamada de novo quando a foto muda)."""
    carimbo = None
    textura = None
    png = None


def atualizar_avatar(carimbo, ao_pronto):
    """carimbo = foto_atualizada_em do /me/resumo. Chama ao_pronto(textura ou None)."""
    if not carimbo:
        CacheFoto.carimbo = CacheFoto.textura = CacheFoto.png = None
        ao_pronto(None)
        return
    if carimbo == CacheFoto.carimbo and CacheFoto.textura is not None:
        ao_pronto(CacheFoto.textura)
        return

    def recebida(r):
        if not r.get("imagem_base64"):
            ao_pronto(None)
            return
        png = base64.b64decode(r["imagem_base64"])
        CacheFoto.carimbo, CacheFoto.png, CacheFoto.textura = carimbo, png, textura_de_png(png)
        ao_pronto(CacheFoto.textura)
    servidor.get("/me/foto", ao_receber=recebida, ao_falhar=lambda m: ao_pronto(None))


# ---------------------------------------------------------------- menu
def _botao(texto, acao, contorno=False):
    b = (Factory.BotaoContorno if contorno else Factory.BotaoVertis)(text=texto, size_hint_y=None, height=dp(46))
    b.bind(on_release=lambda *_: acao())
    return b


def abrir_menu_foto(ao_mudar):
    """Menu: galeria / exemplo / remover. ao_mudar() é chamado depois de salvar ou remover."""
    menu = ModalView(size_hint=(0.88, None), height=dp(300), background="", background_color=(0, 0, 0, 0.45))
    caixa = Factory.Painel(orientation="vertical", spacing=dp(10), padding=dp(18))
    caixa.add_widget(Label(text="[b]Foto de perfil[/b]", markup=True, font_size=sp(17), color=rgba(CORES["texto"]),
                           size_hint_y=None, height=dp(30)))

    def editar(caminho):
        menu.dismiss()
        try:
            img, tex = carregar_imagem(caminho)
        except Exception as e:
            aviso(f"Não consegui abrir a imagem: {e}", erro=True)
            return
        EditorFoto(img, tex, ao_salvar=ao_mudar).open()

    def remover():
        menu.dismiss()
        servidor.delete("/me/foto", ao_receber=lambda r: (aviso("Foto removida"), ao_mudar()),
                        ao_falhar=lambda m: aviso(m, erro=True))

    caixa.add_widget(_botao("Escolher da galeria", lambda: escolher_imagem(editar)))
    caixa.add_widget(_botao("Usar foto de exemplo", lambda: editar(EXEMPLO)))
    caixa.add_widget(_botao("Remover foto", remover, contorno=True))
    caixa.add_widget(_botao("Cancelar", menu.dismiss, contorno=True))
    menu.add_widget(caixa)
    menu.open()
    return menu


# ---------------------------------------------------------------- editor
class EditorFoto(ModalView):
    """Quadrado com a foto + círculo de recorte. Pinça/roda = zoom, arrastar = mover."""

    def __init__(self, imagem, textura, ao_salvar=None, **kw):
        super().__init__(size_hint=(0.96, 0.94), background="", background_color=(0, 0, 0, 0.6),
                         auto_dismiss=False, **kw)
        self._img = imagem
        self._ao_salvar = ao_salvar
        h, w = imagem.shape[:2]
        caixa = Factory.Painel(orientation="vertical", spacing=dp(8), padding=dp(14))
        caixa.add_widget(Label(text="[b]Ajuste sua foto[/b]", markup=True, font_size=sp(17),
                               color=rgba(CORES["texto"]), size_hint_y=None, height=dp(28)))
        caixa.add_widget(Label(text="Pinça (ou roda do mouse) para AMPLIAR  •  arraste para MOVER  •  "
                                    "toque duplo amplia/volta", font_size=sp(11), color=rgba(CORES["texto2"]),
                               size_hint_y=None, height=dp(30), halign="center", text_size=(dp(300), None)))
        self.visor = jn.VisorJanela(textura=textura, tamanho_img=[w, h], cobrir=True, circulo=True,
                                    minimapa=False, zoom_maximo=8, cor_fundo=[0.1, 0.11, 0.13, 1],
                                    size_hint=(None, None))
        quadro = BoxLayout()
        quadro.add_widget(Widget())
        quadro.add_widget(self.visor)
        quadro.add_widget(Widget())
        quadro.bind(size=lambda q, s: setattr(self.visor, "size", (min(s), min(s))))
        caixa.add_widget(quadro)

        linha = BoxLayout(size_hint_y=None, height=dp(34), spacing=dp(8))
        linha.add_widget(Label(text="−", font_size=sp(20), color=rgba(CORES["texto"]), size_hint_x=None, width=dp(20)))
        self.controle = Slider(min=1.0, max=8.0, value=1.0, cursor_size=(dp(22), dp(22)))
        linha.add_widget(self.controle)
        linha.add_widget(Label(text="+", font_size=sp(20), color=rgba(CORES["texto"]), size_hint_x=None, width=dp(20)))
        caixa.add_widget(linha)
        self._sincronizando = False
        self.controle.bind(value=self._controle_mudou)
        self.visor.bind(escala=self._visor_mudou)

        self.detalhe = Label(font_size=sp(10), color=rgba(CORES["texto2"]), size_hint_y=None, height=dp(84),
                             halign="left", valign="top", font_name="RobotoMono-Regular")
        self.detalhe.bind(width=lambda r, wd: setattr(r, "text_size", (wd, None)))
        caixa.add_widget(self.detalhe)
        self.visor.bind(info=self._atualizar_detalhe)

        botoes = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(10))
        botoes.add_widget(_botao("Cancelar", self.dismiss, contorno=True))
        botoes.add_widget(_botao("Salvar foto", self.salvar))
        caixa.add_widget(botoes)
        self.add_widget(caixa)

    def _controle_mudou(self, _s, valor):
        if self._sincronizando:
            return
        self.visor.ampliar(valor / self.visor.nivel_zoom())

    def _visor_mudou(self, *_):
        self._sincronizando = True
        self.controle.value = max(1.0, min(8.0, self.visor.nivel_zoom()))
        self._sincronizando = False

    def _atualizar_detalhe(self, *_):
        x0, y0, x1, y1 = self.visor.janela()
        m = self.visor.matriz()
        self.detalhe.text = (f"zoom {self.visor.nivel_zoom():.1f}x   janela ({x0:.0f}, {y0:.0f}) a ({x1:.0f}, {y1:.0f})\n"
                             f"M = T(viewport) . S(escala) . T(-janela)\n{jn.formatar_matriz(m)}")

    def recorte(self):
        """A parte da foto que fica dentro do círculo, já em 256×256 com fundo transparente."""
        return jn.recorte_circular(self._img, self.visor.janela(), LADO_FOTO)

    def salvar(self):
        png = codificar_png(self.recorte())
        dados = {"imagem_base64": base64.b64encode(png).decode()}

        def ok(_r):
            CacheFoto.carimbo = None          # força baixar a nova foto
            aviso("Foto de perfil atualizada!")
            self.dismiss()
            if self._ao_salvar:
                self._ao_salvar()
        servidor.put("/me/foto", dados, ao_receber=ok, ao_falhar=lambda m: aviso(m, erro=True))
