"""
ABRIR IMAGENS (galeria do celular ou arquivo no computador)
==========================================================
Usado pelo scanner de contas e pelo editor da foto de perfil.
"""
import math
import os

import numpy as np
from kivy.core.image import Image as CoreImage
from kivy.factory import Factory
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.modalview import ModalView
from kivy.utils import platform

from cg import raster
from telas.componentes import aviso

MAX_LADO = 1600   # fotos grandes do celular são reduzidas (memória e velocidade)


def carregar_imagem(caminho, max_lado=MAX_LADO):
    """Arquivo → (matriz NumPy RGBA com a linha 0 EMBAIXO, textura do Kivy)."""
    im = CoreImage(caminho, keep_data=True)
    t = im.texture
    fmt = t.colorfmt
    arr = np.frombuffer(t.pixels, np.uint8).reshape(t.height, t.width, -1)
    if arr.shape[2] == 3:
        arr = np.dstack([arr, np.full(arr.shape[:2], 255, np.uint8)])
    if fmt.startswith("bgr"):
        arr = arr[..., [2, 1, 0, 3]]
    if t.uvsize[1] < 0:                   # textura guardada de cabeça para baixo
        arr = arr[::-1]
    passo = max(1, int(math.ceil(max(arr.shape[:2]) / max_lado)))
    arr = np.ascontiguousarray(arr[::passo, ::passo])
    return arr, raster.para_textura(arr)


def escolher_imagem(ao_escolher):
    """Abre a galeria (Android) ou um seletor de arquivos (computador) e chama ao_escolher(caminho)."""
    if platform == "android":
        try:
            from android.permissions import Permission, request_permissions
            request_permissions([Permission.READ_MEDIA_IMAGES, Permission.READ_EXTERNAL_STORAGE])
        except Exception:
            pass
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=lambda sel: sel and ao_escolher(sel[0]),
                                  filters=[["Imagens", "*.jpg", "*.jpeg", "*.png"]])
        except Exception as e:
            aviso(f"Não consegui abrir a galeria: {e}", erro=True)
        return
    # no computador: seletor de arquivos do próprio Kivy
    janela = ModalView(size_hint=(0.95, 0.8))
    caixa = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))
    seletor = FileChooserListView(path=os.path.expanduser("~"), filters=["*.jpg", "*.jpeg", "*.png", "*.JPG"])
    botao = Factory.BotaoVertis(text="Abrir foto")

    def abrir(*_):
        if seletor.selection:
            janela.dismiss()
            ao_escolher(seletor.selection[0])
    botao.bind(on_release=abrir)
    seletor.bind(on_submit=lambda *a: abrir())
    caixa.add_widget(seletor)
    caixa.add_widget(botao)
    janela.add_widget(caixa)
    janela.open()
