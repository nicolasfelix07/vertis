"""
LUPA DO CARTÃO — AMPLIAR OS DADOS DO CARTÃO
==========================================
Problema: no celular o cartão aparece pequeno, e o cliente precisa LER
os dados (final do número, nome, validade, limite) para conferir ou
digitar numa compra online. Pessoas com baixa visão sofrem mais.

Mesma computação gráfica da foto de perfil (cg/janela.py):
  • a arte do cartão é desenhada numa textura 3× maior (escala S(3) + texto
    renderizado em 3× → continua nítido quando ampliado);
  • a tela mostra uma JANELA dessa textura (transformação janela→viewport);
  • pinça / roda do mouse = zoom no ponto; arrastar = mover a janela;
  • RECORTE: só a parte da janela que está dentro do cartão é desenhada;
  • os botões "Número", "Nome"... escolhem a janela exata daquele dado;
  • o MINIMAPA mostra onde a janela está no cartão inteiro.
"""
from kivy.factory import Factory
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView

from cg import janela as jn
from cg.cartao3d import REGIOES, TAM_TEXTURA
from tema import CORES, rgba

K = 3       # resolução da textura da lupa (3× a do cartão 3D)


class LupaCartao(ModalView):
    def __init__(self, cartao3d, **kw):
        super().__init__(size_hint=(0.97, 0.9), background="", background_color=(0, 0, 0, 0.6), **kw)
        self._faces = dict(zip(("frente", "verso"), cartao3d.desenhar_faces(K)))
        self._face = "frente"
        W, H = TAM_TEXTURA

        caixa = Factory.Painel(orientation="vertical", spacing=dp(8), padding=dp(14))
        topo = BoxLayout(size_hint_y=None, height=dp(30))
        topo.add_widget(Label(text="[b]Lupa do cartão[/b]", markup=True, font_size=sp(17), color=rgba(CORES["texto"]),
                              halign="left", valign="middle", text_size=(dp(220), dp(30))))
        fechar = Factory.BotaoLink(text="Fechar", size_hint_x=None, width=dp(70))
        fechar.bind(on_release=lambda *_: self.dismiss())
        topo.add_widget(fechar)
        caixa.add_widget(topo)
        caixa.add_widget(Label(text="Pinça (ou roda do mouse) para AMPLIAR  •  arraste para MOVER  •  toque duplo",
                               font_size=sp(11), color=rgba(CORES["texto2"]), size_hint_y=None, height=dp(18)))

        self.visor = jn.VisorJanela(textura=self._faces["frente"], tamanho_img=[W * K, H * K], cobrir=False,
                                    minimapa=True, zoom_maximo=5, cor_fundo=list(rgba(CORES["cinza_claro"])),
                                    size_hint_y=1)
        caixa.add_widget(self.visor)

        lados = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        self._botoes_face = {}
        for face, texto in (("frente", "Frente"), ("verso", "Verso")):
            b = Factory.BotaoVertis(text=texto)
            b.bind(on_release=lambda _b, f=face: self.trocar_face(f))
            self._botoes_face[face] = b
            lados.add_widget(b)
        caixa.add_widget(lados)

        caixa.add_widget(Label(text="Ir direto para:", font_size=sp(12), color=rgba(CORES["texto2"]),
                               size_hint_y=None, height=dp(18), halign="left", text_size=(dp(300), None)))
        self.atalhos = BoxLayout(size_hint_y=None, height=dp(38), spacing=dp(6))
        caixa.add_widget(self.atalhos)

        self.detalhe = Label(font_size=sp(10), color=rgba(CORES["texto2"]), halign="left", valign="top",
                             font_name="RobotoMono-Regular", size_hint_y=None, height=dp(84))
        self.detalhe.bind(size=lambda r, s: setattr(r, "text_size", s))
        caixa.add_widget(self.detalhe)
        self.visor.bind(info=self._atualizar_detalhe)
        self.add_widget(caixa)
        self.trocar_face("frente")

    def trocar_face(self, face):
        self._face = face
        self.visor.textura = self._faces[face]
        self.visor._enquadrar()
        for f, b in self._botoes_face.items():
            b.opacity = 1 if f == face else 0.45
        self.atalhos.clear_widgets()
        for nome, (x0, y0, x1, y1) in REGIOES[face].items():
            b = Factory.BotaoContorno(text=nome, font_size=sp(12), height=dp(38))
            b.bind(on_release=lambda _b, r=(x0, y0, x1, y1): self.ir_para(r))
            self.atalhos.add_widget(b)
        tudo = Factory.BotaoContorno(text="Inteiro", font_size=sp(12), height=dp(38))
        tudo.bind(on_release=lambda *_: self.visor.voltar())
        self.atalhos.add_widget(tudo)

    def ir_para(self, regiao):
        """A região está em pixels da arte (k=1): converte para a textura da lupa (k=3)."""
        self.visor.mostrar_regiao(*(v * K for v in regiao))

    def _atualizar_detalhe(self, *_):
        x0, y0, x1, y1 = self.visor.janela()
        self.detalhe.text = (f"zoom {self.visor.nivel_zoom():.1f}x   janela ({x0:.0f}, {y0:.0f}) a ({x1:.0f}, {y1:.0f})\n"
                             f"M = T(viewport) . S(escala) . T(-janela)\n"
                             f"{jn.formatar_matriz(self.visor.matriz())}")
