"""
JANELA, VIEWPORT, RECORTE E AMPLIAÇÃO (ZOOM)
============================================
Conteúdo da disciplina: transformações 2D, janela × viewport, recorte,
texturas e interpolação.

  JANELA   = o pedaço do "mundo" (aqui, da IMAGEM) que queremos ver,
             em coordenadas da imagem (pixels).
  VIEWPORT = o retângulo da TELA onde esse pedaço vai aparecer.

A TRANSFORMAÇÃO JANELA → VIEWPORT é uma composição de 3 matrizes:

        M = T(viewport_min) · S(sx, sy) · T(−janela_min)

    1º leva o canto da janela para a origem   T(−xj_min, −yj_min)
    2º ESCALA para o tamanho do viewport      sx = largura_viewport / largura_janela
    3º leva para o lugar do viewport na tela  T(xv_min, yv_min)

AMPLIAR (zoom) = deixar a JANELA MENOR: o mesmo viewport mostra menos
pixels da imagem, então cada pixel fica maior na tela (sx cresce).

ZOOM EM TORNO DE UM PONTO (pinça / roda do mouse): o ponto da imagem que
está debaixo dos dedos tem de continuar debaixo dos dedos:
        p_img = M⁻¹ · p_tela        (antes do zoom)
        janela_min_nova = p_img − (p_tela − viewport_min) / escala_nova

RECORTE: só a parte da janela que está DENTRO da imagem é desenhada
(interseção de retângulos, o mesmo teste de "dentro/fora" do
Cohen–Sutherland, aplicado aos 4 lados). A placa de vídeo só lê da
textura esse pedaço (tex_coords).

REAMOSTRAGEM: para salvar o recorte (ex.: foto de perfil 256×256),
cada pixel de saída busca a sua cor na imagem original com
INTERPOLAÇÃO BILINEAR e SUPERAMOSTRAGEM (antialiasing).
"""
import math

import numpy as np

from cg import transformacoes as tf


# ======================================================================= MATEMÁTICA
def janela_para_viewport(janela, viewport) -> np.ndarray:
    """janela e viewport = (x_min, y_min, x_max, y_max). Devolve a matriz 3×3."""
    xj0, yj0, xj1, yj1 = janela
    xv0, yv0, xv1, yv1 = viewport
    sx = (xv1 - xv0) / (xj1 - xj0)
    sy = (yv1 - yv0) / (yj1 - yj0)
    return tf.compor(tf.translacao2d(xv0, yv0), tf.escala2d(sx, sy), tf.translacao2d(-xj0, -yj0))


def recortar_retangulo(r, limites):
    """RECORTE de um retângulo por outro (interseção). Devolve None se ficar totalmente fora."""
    x0, y0 = max(r[0], limites[0]), max(r[1], limites[1])
    x1, y1 = min(r[2], limites[2]), min(r[3], limites[3])
    if x0 >= x1 or y0 >= y1:
        return None
    return (x0, y0, x1, y1)


def zoom_no_ponto(janela_min, escala, ponto_tela, viewport_min, nova_escala):
    """Nova posição da janela para que o ponto debaixo dos dedos não saia do lugar."""
    px = janela_min[0] + (ponto_tela[0] - viewport_min[0]) / escala     # p_img = M⁻¹ · p_tela
    py = janela_min[1] + (ponto_tela[1] - viewport_min[1]) / escala
    return (px - (ponto_tela[0] - viewport_min[0]) / nova_escala,
            py - (ponto_tela[1] - viewport_min[1]) / nova_escala)


def limitar_janela(x0, y0, larg, alt, iw, ih, cobrir):
    """Mantém a janela sobre a imagem.
    cobrir=True  → a janela fica SEMPRE inteira dentro da imagem (foto de perfil: sem bordas vazias).
    cobrir=False → se a janela for maior que a imagem, a imagem fica centralizada."""
    def eixo(p, tam, total):
        if tam >= total:
            return (total - tam) / 2 if not cobrir else 0.0
        return min(max(p, 0.0), total - tam)
    return eixo(x0, larg, iw), eixo(y0, alt, ih)


def reamostrar(imagem: np.ndarray, janela, largura: int, altura: int) -> np.ndarray:
    """Recorta a JANELA da imagem e redimensiona para largura×altura.
    imagem: (h, w, 4) uint8 com a linha 0 EMBAIXO. Interpolação BILINEAR + superamostragem k×k."""
    x0, y0, x1, y1 = janela
    hi, wi = imagem.shape[:2]
    # quantos pixels da imagem cabem em 1 pixel da saída → amostras extras para não serrilhar
    k = int(min(4, max(1, math.ceil((x1 - x0) / largura))))
    passo_x, passo_y = (x1 - x0) / largura, (y1 - y0) / altura
    sub = (np.arange(k) + 0.5) / k                             # posições das sub-amostras no pixel
    u = (np.arange(largura)[:, None] + sub[None, :]).ravel()   # largura·k amostras
    v = (np.arange(altura)[:, None] + sub[None, :]).ravel()
    x = x0 + u * passo_x - 0.5                                 # centro do pixel → índice da imagem
    y = y0 + v * passo_y - 0.5
    x = np.clip(x, 0, wi - 1.001)
    y = np.clip(y, 0, hi - 1.001)
    xi, yi = np.floor(x).astype(int), np.floor(y).astype(int)
    fx = (x - xi)[None, :, None]
    fy = (y - yi)[:, None, None]
    img = imagem.astype(np.float32)
    a = img[yi[:, None], xi[None, :]]
    b = img[yi[:, None], xi[None, :] + 1]
    c = img[yi[:, None] + 1, xi[None, :]]
    d = img[yi[:, None] + 1, xi[None, :] + 1]
    amostras = (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy
    # média das k×k sub-amostras de cada pixel (antialiasing)
    saida = amostras.reshape(altura, k, largura, k, 4).mean(axis=(1, 3))
    return np.clip(saida + 0.5, 0, 255).astype(np.uint8)


def mascara_circular(tamanho: int) -> np.ndarray:
    """Alfa de um círculo com borda SUAVE: cobertura = quanto do pixel está dentro do círculo."""
    c = tamanho / 2
    y, x = np.mgrid[0:tamanho, 0:tamanho] + 0.5
    dist = np.hypot(x - c, y - c)
    return np.clip(c - dist + 0.5, 0.0, 1.0)


def recorte_circular(imagem, janela, tamanho=256) -> np.ndarray:
    """Foto de perfil: recorte quadrado da janela + máscara circular (fora do círculo = transparente)."""
    saida = reamostrar(imagem, janela, tamanho, tamanho)
    saida[..., 3] = (saida[..., 3].astype(np.float32) * mascara_circular(tamanho)).astype(np.uint8)
    return saida


def formatar_matriz(m) -> str:
    return "\n".join("[" + "  ".join(f"{v:8.2f}" for v in linha) + " ]" for linha in m)


# ======================================================================= WIDGET (Kivy)
from kivy.animation import Animation                                     # noqa: E402
from kivy.graphics import Color, Line, Mesh, Rectangle, RoundedRectangle  # noqa: E402
from kivy.metrics import dp                                              # noqa: E402
from kivy.properties import (BooleanProperty, ListProperty, NumericProperty,  # noqa: E402
                             ObjectProperty, StringProperty)
from kivy.uix.widget import Widget                                       # noqa: E402


class VisorJanela(Widget):
    """Mostra uma textura através de uma JANELA ajustável.
    Gestos: pinça (2 dedos) = zoom no ponto; arrastar = mover a janela;
    duplo toque = ampliar ali / voltar; roda do mouse = zoom (no computador)."""
    textura = ObjectProperty(None, allownone=True)
    tamanho_img = ListProperty([1, 1])       # largura, altura da imagem em pixels
    escala = NumericProperty(1.0)            # pixels de tela por pixel de imagem (= zoom)
    janela_min = ListProperty([0.0, 0.0])    # canto inferior esquerdo da janela (pixels da imagem)
    zoom_maximo = NumericProperty(6.0)       # em relação ao "caber na tela"
    cobrir = BooleanProperty(False)          # True: a imagem sempre cobre o viewport inteiro
    circulo = BooleanProperty(False)         # escurece fora de um círculo (foto de perfil)
    minimapa = BooleanProperty(True)
    cor_fundo = ListProperty([0.93, 0.94, 0.95, 1])
    info = StringProperty("")                # texto didático (zoom e janela)

    def __init__(self, **kw):
        super().__init__(**kw)
        self._toques = []
        self._pinca = None
        with self.canvas:
            self._c_fundo = Color(*self.cor_fundo)
            self._fundo = Rectangle()
            Color(1, 1, 1, 1)
            self._img = Rectangle()
        with self.canvas.after:
            self._c_veu = Color(0.07, 0.08, 0.1, 0)
            self._veu = Mesh(mode="triangle_strip")
            self._c_aro = Color(1, 1, 1, 0)
            self._aro = Line(width=dp(1.4))
            self._c_mapa = Color(1, 1, 1, 0)
            self._mapa_fundo = RoundedRectangle(radius=[dp(6)])
            self._c_mapa_img = Color(1, 1, 1, 0)
            self._mapa_img = Rectangle()
            self._c_mapa_jan = Color(1, 0.78, 0.1, 0)
            self._mapa_jan = Line(width=dp(1.3))
        self.bind(pos=self._enquadrar, size=self._enquadrar, textura=self._enquadrar,
                  tamanho_img=self._enquadrar, escala=self._desenhar, janela_min=self._desenhar,
                  circulo=self._desenhar, minimapa=self._desenhar,
                  cor_fundo=lambda *_: setattr(self._c_fundo, "rgba", self.cor_fundo))

    # ------------------------------------------------------------------ geometria
    def viewport(self):
        # calculado na mão: right/top do Kivy podem estar desatualizados durante o redimensionamento
        return (self.x, self.y, self.x + self.width, self.y + self.height)

    def escala_inicial(self):
        iw, ih = self.tamanho_img
        if self.cobrir:
            return max(self.width / iw, self.height / ih)    # a imagem cobre o viewport
        return min(self.width / iw, self.height / ih)        # a imagem inteira cabe no viewport

    def janela(self):
        x0, y0 = self.janela_min
        return (x0, y0, x0 + self.width / self.escala, y0 + self.height / self.escala)

    def matriz(self) -> np.ndarray:
        return janela_para_viewport(self.janela(), self.viewport())

    def _enquadrar(self, *_):
        """Volta ao enquadramento inicial (imagem inteira)."""
        if self.width < 2 or self.height < 2:
            return
        Animation.cancel_all(self)
        self.escala = self.escala_inicial()
        self._aplicar_janela(*self._centralizada(self.escala))
        self._desenhar()

    def _centralizada(self, escala):
        iw, ih = self.tamanho_img
        return iw / 2 - self.width / escala / 2, ih / 2 - self.height / escala / 2

    def _aplicar_janela(self, x0, y0):
        iw, ih = self.tamanho_img
        self.janela_min = list(limitar_janela(x0, y0, self.width / self.escala, self.height / self.escala,
                                              iw, ih, self.cobrir))

    def ampliar(self, fator, ponto=None, animar=False):
        """Zoom multiplicando a escala por 'fator', mantendo 'ponto' (da tela) parado."""
        ponto = ponto or (self.x + self.width / 2, self.y + self.height / 2)
        minima = self.escala_inicial()
        nova = min(max(self.escala * fator, minima), minima * self.zoom_maximo)
        x0, y0 = zoom_no_ponto(self.janela_min, self.escala, ponto, (self.x, self.y), nova)
        if animar:
            iw, ih = self.tamanho_img
            jm = limitar_janela(x0, y0, self.width / nova, self.height / nova, iw, ih, self.cobrir)
            Animation.cancel_all(self)
            Animation(escala=nova, janela_min=list(jm), d=0.3, t="out_cubic").start(self)
            return
        self.escala = nova
        self._aplicar_janela(x0, y0)

    def mostrar_regiao(self, x0, y0, x1, y1, margem=1.15):
        """Escolhe a JANELA = região pedida (com margem) → a matriz janela→viewport faz o resto."""
        larg, alt = (x1 - x0) * margem, (y1 - y0) * margem
        minima = self.escala_inicial()
        nova = min(max(min(self.width / larg, self.height / alt), minima), minima * self.zoom_maximo)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        iw, ih = self.tamanho_img
        jm = limitar_janela(cx - self.width / nova / 2, cy - self.height / nova / 2,
                            self.width / nova, self.height / nova, iw, ih, self.cobrir)
        Animation.cancel_all(self)
        Animation(escala=nova, janela_min=list(jm), d=0.45, t="in_out_cubic").start(self)

    def voltar(self):
        alvo = self.escala_inicial()
        Animation.cancel_all(self)
        Animation(escala=alvo, janela_min=list(self._centralizada_limitada(alvo)), d=0.35, t="out_cubic").start(self)

    def mover(self, dx_tela, dy_tela):
        x0, y0 = self.janela_min
        self._aplicar_janela(x0 - dx_tela / self.escala, y0 - dy_tela / self.escala)

    def nivel_zoom(self):
        return self.escala / self.escala_inicial()

    # ------------------------------------------------------------------ desenho
    def _desenhar(self, *_):
        self._fundo.pos, self._fundo.size = self.pos, self.size
        if self.textura is None or self.width < 2:
            self._img.size = (0, 0)
            return
        iw, ih = self.tamanho_img
        jan = self.janela()
        # RECORTE: só a parte da janela que existe na imagem
        visivel = recortar_retangulo(jan, (0, 0, iw, ih))
        if visivel is None:
            self._img.size = (0, 0)
            return
        M = self.matriz()
        (ax, ay), (bx, by) = tf.aplicar2d(M, [visivel[:2], visivel[2:]])
        self._img.pos, self._img.size = (ax, ay), (bx - ax, by - ay)
        self._img.texture = self.textura
        u0, v0, u1, v1 = visivel[0] / iw, visivel[1] / ih, visivel[2] / iw, visivel[3] / ih
        self._img.tex_coords = (u0, v0, u1, v0, u1, v1, u0, v1)   # a GPU só lê esse pedaço da textura

        self._desenhar_circulo()
        self._desenhar_minimapa(jan)
        self.info = (f"zoom {self.nivel_zoom():.1f}x   janela: ({jan[0]:.0f}, {jan[1]:.0f}) a "
                     f"({jan[2]:.0f}, {jan[3]:.0f}) px   escala {self.escala:.2f}")

    def _desenhar_circulo(self):
        if not self.circulo:
            self._c_veu.a = self._c_aro.a = 0
            return
        cx, cy = self.x + self.width / 2, self.y + self.height / 2
        r = min(self.width, self.height) / 2 - dp(2)
        # véu escuro FORA do círculo: faixa de triângulos entre o círculo e a borda do viewport
        vertices, n = [], 72
        meio_w, meio_h = self.width / 2, self.height / 2
        for i in range(n + 1):
            a = 2 * math.pi * i / n
            c, s = math.cos(a), math.sin(a)
            t = min(meio_w / abs(c) if abs(c) > 1e-9 else 1e9, meio_h / abs(s) if abs(s) > 1e-9 else 1e9)
            vertices += [cx + c * r, cy + s * r, 0, 0, cx + c * t, cy + s * t, 0, 0]
        self._veu.vertices = vertices
        self._veu.indices = list(range(2 * (n + 1)))
        self._c_veu.a = 0.55
        self._aro.circle = (cx, cy, r)
        self._c_aro.a = 0.95

    def _desenhar_minimapa(self, jan):
        mostrar = self.minimapa and self.nivel_zoom() > 1.05
        for c in (self._c_mapa, self._c_mapa_img, self._c_mapa_jan):
            c.a = 0
        if not mostrar:
            return
        iw, ih = self.tamanho_img
        lado = dp(84)
        esc = lado / max(iw, ih)
        mw, mh = iw * esc, ih * esc
        mx, my = self.x + self.width - mw - dp(10), self.y + dp(10)
        self._mapa_fundo.pos, self._mapa_fundo.size = (mx - dp(4), my - dp(4)), (mw + dp(8), mh + dp(8))
        self._mapa_img.pos, self._mapa_img.size, self._mapa_img.texture = (mx, my), (mw, mh), self.textura
        visivel = recortar_retangulo(jan, (0, 0, iw, ih)) or (0, 0, 0, 0)
        x0, y0, x1, y1 = (mx + visivel[0] * esc, my + visivel[1] * esc, mx + visivel[2] * esc, my + visivel[3] * esc)
        self._mapa_jan.rectangle = (x0, y0, x1 - x0, y1 - y0)
        self._c_mapa.rgba = (0.07, 0.08, 0.1, 0.75)
        self._c_mapa_img.a = 1
        self._c_mapa_jan.a = 1

    # ------------------------------------------------------------------ gestos
    def on_touch_down(self, toque):
        if not self.collide_point(*toque.pos):
            return super().on_touch_down(toque)
        if toque.is_mouse_scrolling:
            fator = 1.15 if toque.button == "scrolldown" else 1 / 1.15
            self.ampliar(fator, toque.pos)
            return True
        if toque.is_double_tap:
            if self.nivel_zoom() > 1.5:
                self.voltar()
            else:
                self.ampliar(2.5, toque.pos, animar=True)
            return True
        toque.grab(self)
        self._toques.append(toque)
        self._pinca = None
        return True

    def _centralizada_limitada(self, escala):
        iw, ih = self.tamanho_img
        x0, y0 = self._centralizada(escala)
        return limitar_janela(x0, y0, self.width / escala, self.height / escala, iw, ih, self.cobrir)

    def on_touch_move(self, toque):
        if toque.grab_current is not self:
            return super().on_touch_move(toque)
        Animation.cancel_all(self)
        if len(self._toques) >= 2:
            a, b = self._toques[0], self._toques[1]
            dist = math.hypot(a.x - b.x, a.y - b.y)
            meio = ((a.x + b.x) / 2, (a.y + b.y) / 2)
            if self._pinca is not None and self._pinca[0] > 1:
                dist0, meio0 = self._pinca
                self.ampliar(dist / dist0, meio)                    # PINÇA: zoom no ponto entre os dedos
                self.mover(meio[0] - meio0[0], meio[1] - meio0[1])  # e arrasta junto
            self._pinca = (dist, meio)
        else:
            self.mover(toque.dx, toque.dy)
        return True

    def on_touch_up(self, toque):
        if toque.grab_current is not self:
            return super().on_touch_up(toque)
        toque.ungrab(self)
        if toque in self._toques:
            self._toques.remove(toque)
        self._pinca = None
        return True
